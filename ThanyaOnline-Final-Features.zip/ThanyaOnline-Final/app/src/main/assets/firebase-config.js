// Firebase Web SDK configuration for project: thanyaonline-bbe9d
// This file contains client-side Firebase identifiers only. Never put service-account
// credentials or other server secrets in this file.
export const firebaseConfig = {
  apiKey: "AIzaSyDHQtVCgSXvGCYxPOXDkTAbOUSX5qPiZPQ",
  authDomain: "thanyaonline-bbe9d.firebaseapp.com",
  projectId: "thanyaonline-bbe9d",
  storageBucket: "thanyaonline-bbe9d.firebasestorage.app",
  messagingSenderId: "644100389513",
  appId: "1:644100389513:web:45f1f2e7cd8eff0c6e2458",
  measurementId: "G-S1KB7V1ZZM"
};
