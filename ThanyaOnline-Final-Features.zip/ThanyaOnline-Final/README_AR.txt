مشروع ثانوية أونلاين - Android

1) افتح المجلد في Android Studio.
2) انتظر Gradle Sync حتى يكتمل.
3) من Build اختر Build APK(s).
4) ستجد ملف APK داخل:
   app/build/outputs/apk/debug/

المشروع يستخدم WebView لتشغيل واجهة التطبيق الموجودة في:
app/src/main/assets/index.html

الحد الأدنى لأندرويد: 6.0 (API 23).

تم ضبط WebView ليستخدم WebViewAssetLoader و HTTPS-like local origin حتى تعمل Firebase Web SDK modules داخل التطبيق بدل file://.

ملاحظة: Google Sign-In عبر WebView قد يحتاج إعداد OAuth/طريقة تسجيل دخول مناسبة للبيئة المستهدفة؛ البريد/كلمة المرور وFirestore يعملان عبر Firebase Web SDK.
ملاحظة: مساعد الذكاء الاصطناعي الموجود داخل الواجهة حاليًا محلي/تجريبي. للذكاء الاصطناعي الحقيقي يجب إضافة Backend وAPI آمن.
