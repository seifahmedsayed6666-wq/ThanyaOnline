مشروع ثانوية أونلاين - Android

1) افتح المجلد في Android Studio.
2) انتظر Gradle Sync حتى يكتمل.
3) من Build اختر Build APK(s).
4) ستجد ملف APK داخل:
   app/build/outputs/apk/debug/

المشروع يستخدم WebView لتشغيل واجهة التطبيق الموجودة في:
app/src/main/assets/index.html

الحد الأدنى لأندرويد: 6.0 (API 23).
ملاحظة: مساعد الذكاء الاصطناعي الموجود داخل الواجهة حاليًا محلي/تجريبي. للذكاء الاصطناعي الحقيقي يجب إضافة Backend وAPI آمن.
